plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yongyong.subtranslator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yongyong.subtranslator"
        minSdk = 29
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")

    // 네트워크 (구글 STT / 번역 REST 호출용)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // 비동기 처리
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
