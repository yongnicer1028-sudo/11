package com.yongyong.subtranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.abs

/**
 * 이 서비스 하나가 전부 다 해요:
 * 1. 영상 앱이 재생 중인 소리를 내부적으로 가져오고 (마이크 아님, 이어폰 껴도 됨)
 * 2. "말하는 구간"만 자동으로 잘라내서 (침묵 감지 = VAD) 구글 음성인식(STT)으로 글자를 만들고
 * 3. 구글 클라우드 번역(무료 한도 내)으로 한국어로 번역하고
 * 4. 화면 위에 떠 있는 작은 자막창에 표시해요.
 *
 * v0.2에서 바뀐 점 (속도/퀄리티 개선, 여전히 100% 무료):
 * - 예전: 무조건 3.5초마다 뚝뚝 잘라서 보냄 → 문장이 중간에 잘리기 쉬움
 * - 지금: 실제 "말소리가 있는 구간"만 감지해서, 조용해지는 순간 바로 그 문장을 보냄
 *         → 대기 시간도 줄고, 문장이 안 잘려서 인식 정확도도 올라감
 * - 예전: 처리 중일 때 들어온 소리는 그냥 버림 → 자막이 자주 빠짐
 * - 지금: 처리 중이어도 그 다음 문장을 큐에 담아뒀다가 순서대로 처리 (최신 것 우선)
 *
 * v0.3에서 바뀐 점 (엉뚱한 자막 문제 대응):
 * - 구글이 인식 결과에 "얼마나 확신하는지"(confidence)를 같이 주는데, 그 값이 낮으면
 *   아예 자막을 안 띄워요. 엉뚱한 문장이 뜨는 것보다 잠깐 안 뜨는 게 나으니까요.
 * - 배경음악/효과음을 말소리로 착각하는 걸 줄이려고 VAD 민감도를 좀 더 보수적으로 조정했어요.
 * - 번역(한국어) 위에 인식된 원문도 작게 같이 보여줘요. 번역이 이상할 때
 *   "원문 인식 자체가 틀린 건지, 번역만 이상한 건지" 바로 구분할 수 있어요.
 *
 * v0.4에서 바뀐 점 (번역 품질 개선):
 * - 폰 안에서 처리하던 ML Kit 번역이 직역투로 딱딱하다는 피드백이 있어서,
 *   같은 구글 계정의 클라우드 번역(신경망 기반, 매달 50만 글자 무료)으로 바꿨어요.
 *   자막 용도로는 50만 글자면 사실상 거의 다 써도 될 정도로 넉넉해요.
 * - 대신 번역할 때도 인터넷이 필요해요 (음성인식도 어차피 인터넷이 필요했어서 실질적 차이는 없어요).
 * - 폰 안에 번역 모델을 내려받는 과정이 없어져서 시작 속도도 조금 더 빨라졌어요.
 */
class TranslateOverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        private const val NOTIF_CHANNEL_ID = "sub_translator_channel"
        private const val NOTIF_ID = 1001

        private const val SAMPLE_RATE = 16000

        // ── 아래 숫자들은 "말소리 감지(VAD)" 민감도예요.
        //    자막이 잘 안 뜨면 VOICE_THRESHOLD를 낮추고, 잡음/음악까지 자막이 뜨면 높여보세요.
        private const val FRAME_MS = 20
        private const val FRAME_BYTES = SAMPLE_RATE / 1000 * FRAME_MS * 2 // 16bit = 2byte
        private const val VOICE_THRESHOLD = 550        // 이보다 크면 "말소리 있음" (v0.3: 잡음 오탐 줄이려고 상향)
        private const val SILENCE_HANGOVER_MS = 600     // 이만큼 조용하면 "문장 끝"으로 보고 전송
        private const val MIN_SEGMENT_MS = 600          // 이보다 짧으면 잡음으로 보고 버림 (v0.3: 너무 짧은 조각은 오인식이 많아서 상향)
        private const val MAX_SEGMENT_MS = 8000         // 말이 계속 이어져도 이 길이가 되면 일단 끊어서 보냄

        // v0.3: 구글이 "자신 없다"고 한 결과는 아예 안 보여줌 (엉뚱한 자막보다 안 뜨는 게 나아요)
        private const val CONFIDENCE_THRESHOLD = 0.55f

        /** MainActivity가 화면에 "실행 중" 표시를 하기 위해 확인하는 값 */
        @Volatile
        var isRunning: Boolean = false
    }

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var capturing = false
    private var segmentChannel: Channel<ByteArray>? = null

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var captionText: TextView? = null
    private var originalText: TextView? = null

    private lateinit var speechClient: GoogleSpeechClient
    private lateinit var translateClient: GoogleTranslateClient
    private var sourceLangCode: String = "cmn-Hans-CN"
    private var sourceLangShort: String = "zh"

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // 안드로이드 14 이상은 반드시 "포그라운드 서비스 시작"이 먼저이고,
        // 그 다음에 화면(소리) 캡처 권한을 사용해야 해요. 순서를 지켜야 크래시가 안 나요.
        startForegroundNotification()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData: Intent? =
            if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val language = Prefs.getLanguage(this)
        sourceLangCode = Prefs.speechLanguageCode(language)
        sourceLangShort = language // Prefs의 "zh"/"ja"/"en" 값이 번역 API 코드로 그대로 쓰여요

        val apiKey = Prefs.getApiKey(this)
        speechClient = GoogleSpeechClient(apiKey)
        translateClient = GoogleTranslateClient(apiKey)

        showOverlay()
        updateCaptionSync("듣는 중…")
        beginCapture(resultCode, resultData)

        return START_STICKY
    }

    private fun beginCapture(resultCode: Int, resultData: Intent) {
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        if (projection == null) {
            updateCaptionSync("소리 캡처 권한을 가져오지 못했어요.")
            return
        }
        mediaProjection = projection
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, null)

        startAudioCapture(projection)
        isRunning = true
    }

    private fun startForegroundNotification() {
        val notifManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL_ID, "실시간 번역", NotificationManager.IMPORTANCE_LOW
            )
            notifManager.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setContentTitle("영상 소리를 번역하고 있어요")
            .setContentText("탭하면 앱으로 돌아가요 · 중지하려면 앱에서 '번역 중지'를 누르세요")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun showOverlay() {
        if (overlayView != null) return

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_caption, null)
        captionText = view.findViewById(R.id.textCaption)
        originalText = view.findViewById(R.id.textOriginal)

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 160
        }

        // 손가락으로 자막창을 드래그해서 원하는 위치로 옮길 수 있게
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(view, params)
            overlayView = view
        } catch (e: Exception) {
            // 오버레이 권한이 없는 등 예외 상황 - 알림으로만 상태를 알림
        }
    }

    private fun startAudioCapture(projection: MediaProjection) {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = if (minBuf > 0) minBuf * 2 else SAMPLE_RATE * 2

        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setAudioPlaybackCaptureConfig(captureConfig)
                .build()
        } catch (e: Exception) {
            updateCaptionSync("오디오 캡처를 시작할 수 없어요: ${e.message}")
            return
        }

        audioRecord = record
        record.startRecording()
        capturing = true

        // 문장 단위로 잘린 오디오 조각이 도착하는 통로.
        // CONFLATED: 처리(STT+번역)가 밀리면 오래된 것 대신 "가장 최근" 문장을 우선 처리해서
        // 자막이 계속 뒤로 밀리는 걸 막아줘요.
        val channel = Channel<ByteArray>(capacity = Channel.CONFLATED)
        segmentChannel = channel

        // 워커 1: 완성된 문장 조각을 순서대로 하나씩 처리 (STT → 번역 → 자막 표시)
        serviceScope.launch {
            for (segment in channel) {
                processSegment(segment)
            }
        }

        // 워커 2: 오디오를 20ms 단위로 읽으면서, 말소리 유무로 문장 경계를 자동으로 찾음
        serviceScope.launch {
            val frameBuf = ByteArray(FRAME_BYTES)
            val segmentBuf = ByteArrayOutputStream()
            var inSpeech = false
            var silenceMs = 0
            var segmentMs = 0

            while (capturing) {
                val filled = readFully(record, frameBuf)
                if (filled <= 0) {
                    if (filled < 0) break
                    delay(5) // 데이터가 아직 없으면 살짝 쉬었다가 다시 시도 (배터리/CPU 보호)
                    continue
                }

                val voiced = isVoiced(frameBuf)

                if (voiced) {
                    segmentBuf.write(frameBuf)
                    segmentMs += FRAME_MS
                    silenceMs = 0
                    inSpeech = true
                } else if (inSpeech) {
                    // 말하다가 잠깐 조용해진 구간 - 문장이 끝났는지 확인하려고 잠깐 더 들어봐요
                    segmentBuf.write(frameBuf)
                    segmentMs += FRAME_MS
                    silenceMs += FRAME_MS
                }

                val endedBySilence = inSpeech && silenceMs >= SILENCE_HANGOVER_MS
                val endedByMaxLength = inSpeech && segmentMs >= MAX_SEGMENT_MS

                if (endedBySilence || endedByMaxLength) {
                    if (segmentMs >= MIN_SEGMENT_MS) {
                        channel.trySend(segmentBuf.toByteArray())
                    }
                    segmentBuf.reset()
                    inSpeech = false
                    silenceMs = 0
                    segmentMs = 0
                }
            }
            channel.close()
        }
    }

    /** buffer가 꽉 찰 때까지 반복해서 읽어요 (AudioRecord가 한 번에 조금씩만 줄 때가 있어서) */
    private fun readFully(record: AudioRecord, buffer: ByteArray): Int {
        var offset = 0
        while (offset < buffer.size) {
            val n = try {
                record.read(buffer, offset, buffer.size - offset)
            } catch (e: Exception) {
                return -1
            }
            if (n <= 0) return n
            offset += n
        }
        return offset
    }

    /** 이 프레임(20ms)에 사람 말소리 같은 게 있는지 아주 단순하게 판단 (평균 진폭 기준) */
    private fun isVoiced(frame: ByteArray): Boolean {
        var sum = 0L
        var i = 0
        while (i + 1 < frame.size) {
            val sample = ((frame[i].toInt() and 0xFF) or (frame[i + 1].toInt() shl 8)).toShort().toInt()
            sum += abs(sample)
            i += 2
        }
        val sampleCount = frame.size / 2
        if (sampleCount == 0) return false
        return (sum / sampleCount) > VOICE_THRESHOLD
    }

    private suspend fun processSegment(pcm: ByteArray) {
        val result = speechClient.recognize(pcm, sourceLangCode)
        if (result.transcript.isBlank()) return

        // 구글이 자신 없어하는 결과는 걸러서, 엉뚱한 자막이 뜨는 걸 줄여요.
        if (result.confidence < CONFIDENCE_THRESHOLD) return

        showOriginal(result.transcript)
        translateAndShow(result.transcript)
    }

    private suspend fun showOriginal(text: String) {
        withContext(Dispatchers.Main) {
            originalText?.text = text
            originalText?.visibility = View.VISIBLE
        }
    }

    private suspend fun translateAndShow(text: String) {
        val translated = translateClient.translate(text, sourceLangShort)
        updateCaption(translated)
    }

    private suspend fun updateCaption(text: String) {
        withContext(Dispatchers.Main) {
            captionText?.text = text
        }
    }

    /** onStartCommand처럼 suspend가 아닌 곳에서 자막을 바로 바꾸고 싶을 때 */
    private fun updateCaptionSync(text: String) {
        captionText?.post { captionText?.text = text }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        capturing = false
        segmentChannel?.close()
        segmentChannel = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null

        mediaProjection?.stop()
        mediaProjection = null

        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlayView = null

        serviceJob.cancel()
        super.onDestroy()
    }
}
