package com.yongyong.subtranslator

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 구글 클라우드 Translation API(v2)를 호출해서 텍스트를 번역해요.
 * (매달 50만 글자까지 무료 — 자막 용도로는 사실상 거의 무제한이에요)
 *
 * v0.4에서 ML Kit(폰 안에서 처리, 오프라인)에서 이걸로 바꿨어요.
 * ML Kit은 무료지만 번역 품질이 직역투로 딱딱하게 나오는 경우가 많아서,
 * 같은 구글 계정의 더 좋은 번역 엔진(신경망 기반)을 쓰도록 바꿨어요.
 * 대신 이제는 번역할 때마다 인터넷이 필요해요 (어차피 음성인식도 인터넷이 필요해서 큰 차이는 없어요).
 */
class GoogleTranslateClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * sourceLang: "zh" / "ja" / "en" 같은 짧은 언어 코드
     * 실패하면 원문을 그대로 돌려줘요 (자막이 아예 안 뜨는 것보단 나으니까요)
     */
    fun translate(text: String, sourceLang: String, targetLang: String = "ko"): String {
        if (apiKey.isBlank() || text.isBlank()) return text

        val json = JSONObject().apply {
            put("q", text)
            put("source", sourceLang)
            put("target", targetLang)
            put("format", "text")
        }

        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://translation.googleapis.com/language/translate/v2?key=$apiKey")
            .post(body)
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyText = response.body?.string() ?: return text
                if (!response.isSuccessful) return text

                val root = JSONObject(bodyText)
                val translations = root.optJSONObject("data")?.optJSONArray("translations") ?: return text
                if (translations.length() == 0) return text

                translations.getJSONObject(0).optString("translatedText", text)
            }
        } catch (e: Exception) {
            text
        }
    }
}
