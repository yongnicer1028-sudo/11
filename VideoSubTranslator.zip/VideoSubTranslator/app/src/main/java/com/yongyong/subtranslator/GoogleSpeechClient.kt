package com.yongyong.subtranslator

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Base64
import java.util.concurrent.TimeUnit

/** 인식된 문장과, 구글이 그 결과를 얼마나 확신하는지(0.0~1.0) 같이 담아요. */
data class SpeechResult(val transcript: String, val confidence: Float)

/**
 * 구글 클라우드 Speech-to-Text REST API를 호출해서
 * 짧은 오디오 조각(pcm16)을 텍스트로 바꿔주는 아주 작은 도우미 클래스.
 * (매달 60분까지 무료, 그 이후는 과금됩니다)
 */
class GoogleSpeechClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * pcm16 = 16bit / 16000Hz / mono 원시 오디오 바이트
     * 실패하거나 무음이면 transcript가 빈 문자열("")로 와요.
     */
    fun recognize(pcm16: ByteArray, languageCode: String): SpeechResult {
        if (apiKey.isBlank()) return SpeechResult("", 0f)

        val audioBase64 = Base64.getEncoder().encodeToString(pcm16)

        val json = JSONObject().apply {
            put("config", JSONObject().apply {
                put("encoding", "LINEAR16")
                put("sampleRateHertz", 16000)
                put("languageCode", languageCode)
                put("enableAutomaticPunctuation", true)
            })
            put("audio", JSONObject().apply {
                put("content", audioBase64)
            })
        }

        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://speech.googleapis.com/v1/speech:recognize?key=$apiKey")
            .post(body)
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyText = response.body?.string() ?: return SpeechResult("", 0f)
                if (!response.isSuccessful) return SpeechResult("", 0f)

                val root = JSONObject(bodyText)
                val results = root.optJSONArray("results") ?: return SpeechResult("", 0f)

                val sb = StringBuilder()
                var minConfidence = 1f
                var sawConfidence = false

                for (i in 0 until results.length()) {
                    val alternatives = results.getJSONObject(i).optJSONArray("alternatives") ?: continue
                    if (alternatives.length() > 0) {
                        val alt = alternatives.getJSONObject(0)
                        sb.append(alt.optString("transcript", ""))

                        val conf = alt.optDouble("confidence", -1.0)
                        if (conf >= 0.0) {
                            sawConfidence = true
                            minConfidence = minOf(minConfidence, conf.toFloat())
                        }
                    }
                }

                // 구글이 confidence 값을 안 준 경우엔 일단 통과시키고(0.75),
                // 값을 줬는데 낮으면 그대로 낮은 값을 써서 걸러낼 수 있게 해요.
                val confidence = if (sawConfidence) minConfidence else 0.75f
                SpeechResult(sb.toString().trim(), confidence)
            }
        } catch (e: Exception) {
            SpeechResult("", 0f)
        }
    }
}
